module.exports = [
"[project]/.next-internal/server/app/noticias/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_noticias_%5Bslug%5D_page_actions_1cd828eb.js.map