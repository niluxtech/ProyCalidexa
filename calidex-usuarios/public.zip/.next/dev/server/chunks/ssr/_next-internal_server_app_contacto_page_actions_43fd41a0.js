module.exports = [
"[project]/.next-internal/server/app/contacto/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_contacto_page_actions_43fd41a0.js.map