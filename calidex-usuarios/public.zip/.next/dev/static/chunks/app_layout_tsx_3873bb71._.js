(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__c1537bae._.css",
  "static/chunks/node_modules_1471dd48._.js",
  "static/chunks/app_components_d0d77db8._.js"
],
    source: "dynamic"
});
